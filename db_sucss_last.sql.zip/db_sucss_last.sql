-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2017 at 10:41 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_sucss_last`
--

-- --------------------------------------------------------

--
-- Table structure for table `acadamic_year`
--

CREATE TABLE IF NOT EXISTS `acadamic_year` (
  `acadamic_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `acadamic_year` varchar(50) NOT NULL,
  PRIMARY KEY (`acadamic_year_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `acadamic_year`
--

INSERT INTO `acadamic_year` (`acadamic_year_id`, `acadamic_year`) VALUES
(1, '2017 GC (2009EC)');

-- --------------------------------------------------------

--
-- Table structure for table `bulding`
--

CREATE TABLE IF NOT EXISTS `bulding` (
  `bulding_id` int(1) NOT NULL AUTO_INCREMENT,
  `bulding_name` varchar(30) NOT NULL,
  `no_of_room` int(11) NOT NULL,
  PRIMARY KEY (`bulding_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `bulding`
--

INSERT INTO `bulding` (`bulding_id`, `bulding_name`, `no_of_room`) VALUES
(1, 'Reg A', 12),
(3, 'Reg B', 10),
(8, 'Bulding 1', 20),
(5, 'Reg C', 9),
(9, 'Bulding 2', 20),
(10, 'Lh1 and Lh 2 (old) ', 2),
(11, 'Lh 3 & Lh 4 (New)', 2),
(12, 'Cs Lab ', 4),
(13, 'block 112', 2);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `comments` text,
  `msg_id_fk` int(11) DEFAULT NULL,
  PRIMARY KEY (`com_id`),
  KEY `msg_id_fk` (`msg_id_fk`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`com_id`, `comments`, `msg_id_fk`) VALUES
(1, 'Why?', 4),
(2, 'i heat this news!!!! :(', 4),
(3, 'I Think Mr. Mohammed Osmann was Better!!', 1),
(4, 'wow thts realy cool lol ', 2);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(30) NOT NULL,
  `course_code` varchar(100) NOT NULL,
  `course_title` varchar(100) NOT NULL,
  `course_category` varchar(100) NOT NULL,
  `year` varchar(30) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `lab_hours` varchar(50) NOT NULL,
  `lecture_hours` varchar(50) NOT NULL,
  `total_chr` varchar(40) NOT NULL,
  `mode_of_delivery` varchar(30) NOT NULL,
  `instractor` varchar(100) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `course_code` (`course_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `department`, `course_code`, `course_title`, `course_category`, `year`, `semester`, `lab_hours`, `lecture_hours`, `total_chr`, `mode_of_delivery`, `instractor`, `note`) VALUES
(20, 'information science', 'INSC 3143', 'information marketing', 'Major', '3rd year', '2nd', 'No Lab', '2 hrs', '3', 'Parallel', 'Mr.hasen', 'marketing'),
(17, 'information science', 'INSC 3142', 'information literacy', 'Major', '3rd year', '2nd', 'No Lab', '2 hrs', '3', 'Parallel', 'Mr.obsa', 'health'),
(79, 'Computer Science', 'CS201', 'Introduction to computer Scinece', 'Major', '1st year', '1st', '3 hrs', '3 hrs', '4', 'Block', 'Mr.x', 'this is edited course the instructor changed.'),
(2, 'Plant science', 'www', 'wwww', 'Major', '3rd year', '1st', 'No Lab', '3 hrs', '3', 'Parallel', '', 'agriculture'),
(21, 'information techinology', 'eee', 'eeeeee', 'Minor', '4th year', '1st', 'No Lab', '3 hrs', '3', 'Parallel', '', ''),
(22, 'information science', 'INSC 3144', 'networking', 'Major', '2nd year', '2nd', '1 hrs', '2 hrs', '5', 'Parallel', 'mr.mokonen', ''),
(23, 'Computer scines', 'cs 223', 'programming 2', 'Major', '2nd year', '2nd', '2 hrs', '3 hrs', '4', 'Parallel', '', ''),
(24, 'Computer scines', 'cs 233', 'computer disign and archtecture', 'Major', '2nd year', '2nd', 'No Lab', '3 hrs', '3', 'Parallel', '', ''),
(25, 'Computer scines', 'cs244', 'information system', 'Major', '2nd year', '1st', 'No Lab', '3 hrs', '3', 'Parallel', '', ''),
(28, 'Computer Science', 'Phil201', 'Introduction to Logic', 'Minor', '1st year', '1st', 'No Lab', '3 hrs', '3', 'Block', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `faculity_name` varchar(150) NOT NULL,
  `department_name` varchar(150) NOT NULL,
  `person_incharge` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`department_id`),
  UNIQUE KEY `department_name` (`department_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `faculity_name`, `department_name`, `person_incharge`, `address`) VALUES
(55, 'Faculty of Engineering and Technology(FET)', 'information science', 'Mr mokonon', 'block 112'),
(25, 'Faculty of Engineering and Technology(FET)', 'Computer Science', 'Mr.x', 'block 107'),
(54, 'Faculty of Engineering and Technology(FET)', 'Civil Engineering', 'Mr x', 'block 110'),
(53, 'Faculty of Engineering and Technology(FET)', 'Information Technology', 'Mr x', 'block 112'),
(56, 'Faculty of Engineering and Technology(FET)', 'Electrical Engineering', 'Mr x', 'block 110'),
(57, 'Faculty of Engineering and Technology(FET)', 'Mechanical Engineering', 'Mr x', 'block 107'),
(58, 'Faculity of Bussiness and Economics(FBE)', 'Accounting', 'Mr x', 'Social science Block B-115'),
(59, 'Faculity of Bussiness and Economics(FBE)', 'Economics', 'Mr x', 'Social science Block B-115'),
(60, 'Faculity of Dryland Agreculture(FDA)', 'plant_science', 'x', 'block 034'),
(61, 'Faculity of Bussiness and Economics(FBE)', 'Business and Administrative', 'Mr.', 'Block'),
(62, 'Faculity of Dryland Agreculture(FDA)', 'Animal Science', 'Mr x', 'block 034'),
(64, 'Faculity of Dryland Agreculture(FDA)', 'Natural Resource Management', 'x', 'block 034'),
(67, 'Faculity of Natural and Computational science(FNCS', 'Biology ', 'Mr x', 'block 109'),
(68, 'Faculity of Natural and Computational science(FNCS', 'Chemistry', 'Mr x', 'block 109'),
(70, 'Faculity of Natural and Computational science(FNCS', 'Mathematics', 'Mr x', 'block 109'),
(71, 'Faculity of Natural and Computational science(FNCS', 'Physics', 'Mr x', 'block 115'),
(72, 'Faculity of Natural and Computational science(FNCS', 'Statistics', 'Mr x', 'block 115'),
(74, 'Faculity of Social Science and Humanity(FSSH)', 'Antropology', 'Mr x', 'Social science Block B-115'),
(75, 'Faculity of Social Science and Humanity(FSSH)', 'afaan oromoo', 'Mr x', 'Social science Block B-115'),
(76, 'Faculity of Social Science and Humanity(FSSH)', 'Forign Language and Literature (English)', 'Mr x', 'Social science Block B-115'),
(78, 'Faculity of Social Science and Humanity(FSSH)', 'Geography', 'Mr x', 'Social science Block B-115'),
(79, 'Faculity of Social Science and Humanity(FSSH)', 'History', 'Mr Abreham Habtom', 'Social science Block B-54'),
(80, 'Faculity of Social Science and Humanity(FSSH)', 'law', 'Mr.x', 'Social science Block-B-123'),
(82, 'Faculity of Social Science and Humanity(FSSH)', 'Civic and Ethical Education', 'Mr Addisalem.B', 'Social science Block B-45');

-- --------------------------------------------------------

--
-- Table structure for table `faculity`
--

CREATE TABLE IF NOT EXISTS `faculity` (
  `faculity_id` int(11) NOT NULL AUTO_INCREMENT,
  `faculity_name` varchar(100) NOT NULL,
  `person_incharge` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`faculity_id`),
  UNIQUE KEY `faculity_name` (`faculity_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `faculity`
--

INSERT INTO `faculity` (`faculity_id`, `faculity_name`, `person_incharge`, `address`) VALUES
(1, 'Faculty of Engineering and Technology(FET)  ', 'Mr x', 'Engineering building-R-205'),
(2, 'Faculity of Bussiness and Economics(FBE)', 'Mr Ali Hussen', 'Registrar Building R-59'),
(3, 'Faculity of Dryland Agreculture(FDA)', 'Mr Kebede Feyesa', 'Natural science Block B-82'),
(4, 'Faculity of Natural and Computational science(FNCS', 'Mr Adisu Kinfu', 'Natural science Block B-300'),
(5, 'Faculity of Social Science and Humanity(FSSH)', 'Mr Abdurehman Talema', 'Social science Block B-56'),
(6, 'Faculty of Health Science', 'Mr Chalachew', 'Academic Vice presedant Block'),
(7, 'engineering and techinology', 'mr.x', 'registeral building');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `comment` text NOT NULL,
  `to` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `name`, `email`, `comment`, `to`, `date`) VALUES
(1, 'chimdesa ', 'chimdesainfosa@gmail.com', 'This is try try try!!!', '', '2017-06-21'),
(2, 'tasfe', 'tasfeinfosa@yahoo.com', 'I think it working', '', '2017-06-21'),
(3, 'habtamu negash', 'habtish@yahoo.com', 'Congradulation feedback is working with validation!!!!', '', '2017-06-21'),
(5, 'mokonen (Dep Head)', 'mokonen@email.com', 'O! 10x admin I thouth that u will not see that message but u see it ha! any way I will wait ur response soon.', '', '2017-06-21'),
(6, 'mersani', 'mersani@mb', 'Hi Admin This is Scheduler MB and its working i recived your Notice and congratulation!!', '', '2017-06-21'),
(7, 'ashu', 'cvvbnv@gmail.com', 'www', '', '2017-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_scheduler`
--

CREATE TABLE IF NOT EXISTS `feedback_scheduler` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `comment` text NOT NULL,
  `to` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `feedback_scheduler`
--

INSERT INTO `feedback_scheduler` (`feedback_id`, `name`, `email`, `comment`, `to`, `date`) VALUES
(1, 'Admin MB', 'admin@mb', 'Hi Scheduler this is Admin for trying the system!', '', '2017-06-21'),
(2, 'Admin MB', 'admin@mb', 'Hi Scheduler,\r\ninfosa section two students says there is some problem on the schedule and when i caked it yeas there is!\r\nu prepare the schedule for the course !!', '', '2017-06-21'),
(3, 'Admin MB', 'admin@mb', 'This is Admin MB, how u doing scheduler?\r\nya i see the schedule now its corrected 10x for your fast response!!!', '', '2014-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_user`
--

CREATE TABLE IF NOT EXISTS `feedback_user` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `comment` text NOT NULL,
  `to` varchar(30) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `feedback_user`
--

INSERT INTO `feedback_user` (`feedback_id`, `name`, `email`, `comment`, `to`, `date`) VALUES
(1, 'Admin MB', 'admin@mb', 'hi user i see ur message and i promiss i will fix that as soom as possible and 10x for ur info Br', '', '2017-06-21'),
(2, 'Admin MB', 'admin@mb', 'Hi infosa Dep Head, Ya I see the problem and i will work hard to find solution in short time!!!\r\nand 10x for ur information!', '', '2017-06-21'),
(3, 'Admin MB`', 'admin@mb', 'Hi User This is Admin MB,\r\nok i see that and i will change the old course with this one!!!', '', '2017-06-21'),
(4, 'Scheduler MB', 'scheduler@mb', 'Hi User This is Scheduler MB, For infosa Dep Head, ya when i revised the schedule i find the problem so i will fix it soon, and 10x for ur Info!!!', '', '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `data` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `user` varchar(20) NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=165 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `date`, `data`, `action`, `user`) VALUES
(1, '2017-06-20 12:20:10', 'chimdesa gedefa', 'Login', 'Admin'),
(2, '2017-06-20 12:20:49', 'aaa', 'Add Entry Department', 'Admin'),
(3, '2017-06-20 12:21:34', 'tesfaye tadese', 'Add Entry Department', 'Admin'),
(4, '2017-06-20 12:21:42', 'habtamu negash', 'Delete Department', 'admin'),
(5, '2017-06-20 12:35:58', 'mersani negash', 'Login', 'Admin'),
(6, '2017-06-20 12:36:04', 'chimdesa gedefa', 'Login', 'Admin'),
(7, '2017-06-20 12:37:07', 'chimdesa gedefa', 'Login', 'Admin'),
(16, '2017-06-20 16:39:45', ' ', 'Login', ''),
(18, '2017-06-20 16:40:39', 'chimdesa gedefa', 'Login', 'Admin'),
(19, '2017-06-20 16:46:07', 'AAAFFFAAAA', 'Add Entry Faculityt', 'Admin'),
(128, '2017-03-01 08:09:57', 'Abdul hamid Nesru', 'Login', 'Admin'),
(129, '2017-03-01 08:10:40', '', 'Add Entry Instractor', 'bdfdfdfdfdfd'),
(130, '2017-03-01 08:18:47', '3rd', 'Add Entry Course', 'Admin'),
(131, '2017-03-01 08:45:16', '2017 GC (2009EC)', 'Update Entry Acadamic Year', 'Admin'),
(132, '2017-03-01 08:47:58', 'Abdul hamid Nesru', 'Logout', 'Admin'),
(133, '2017-03-01 08:48:31', 'Abdul hamid Nesru', 'Login', 'Scheduler'),
(134, '2017-03-01 08:55:18', 'Abdul hamid Nesru', 'Login', 'Scheduler'),
(135, '2017-03-01 09:36:05', 'tesfaye  tadese', 'Logout', 'Scheduler'),
(136, '2017-03-01 09:45:46', 'tesfaye  tadese', 'Login', 'Scheduler'),
(137, '2017-03-01 09:46:31', 'tesfaye  tadese', 'Logout', 'Scheduler'),
(138, '2017-03-01 09:46:47', 'mersani below', 'Login', 'User'),
(139, '2017-03-01 10:37:17', 'chimdesa  gedefa', 'Login', 'Admin'),
(140, '2017-03-01 21:08:26', 'chimdesa  gedefa', 'Login', 'Admin'),
(141, '2017-03-01 21:09:37', 'engineering and techinology', 'Add Entry Faculityt', 'Admin'),
(142, '2017-03-01 21:11:53', 'block 112', 'Add Entry Bulding', 'Admin'),
(143, '2017-03-01 21:12:56', 'infosa section 2', 'Add Entry Room', 'Admin'),
(144, '2017-03-01 21:13:50', 'hy ashu', 'Update Notification', 'Admin'),
(145, '2017-03-01 21:14:54', 'mersani below', 'Login', 'User'),
(146, '2017-03-01 21:15:54', 'chimdesa  gedefa', 'Login', 'Admin'),
(147, '2017-03-02 03:43:17', 'chimdesa  gedefa', 'Login', 'Admin'),
(148, '2017-03-02 03:44:24', 'ararsa&nbsp;girma', 'Add User', 'Admin'),
(149, '2017-03-02 03:44:40', 'chimdesa  gedefa', 'Logout', 'Admin'),
(150, '2017-03-02 03:45:07', 'ararsa girma', 'Login', 'User'),
(151, '2017-03-02 08:53:45', 'mersani below', 'Login', 'User'),
(152, '2017-03-02 08:54:06', 'chimdesa  gedefa', 'Login', 'Admin'),
(153, '2017-03-06 07:53:57', 'chimdesa  gedefa', 'Login', 'Admin'),
(154, '2017-03-06 07:57:24', 'chimdesa  gedefa', 'Login', 'Admin'),
(155, '2017-03-06 08:29:41', 'mersani below', 'Login', 'User'),
(156, '2017-03-06 09:01:41', 'chimdesa  gedefa', 'Login', 'Admin'),
(157, '2017-03-06 09:02:14', 'chimdesa  gedefa', 'Logout', 'Admin'),
(158, '2017-03-06 09:02:24', 'mersani below', 'Login', 'User'),
(159, '2017-03-06 09:09:04', 'mersani below', 'Logout', 'User'),
(160, '2017-03-06 23:41:05', 'chimdesa  gedefa', 'Login', 'Admin'),
(161, '2017-03-07 07:44:10', 'chimdesa  gedefa', 'Login', 'Admin'),
(162, '2017-03-07 07:45:06', 'vbvnbn&nbsp;zxxzcxcvc', 'Add User', 'Admin'),
(163, '2017-03-07 07:45:20', 'chimdesa  gedefa', 'Logout', 'Admin'),
(164, '2017-03-07 07:45:35', 'vbvnbn zxxzcxcvc', 'Login', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `instractor`
--

CREATE TABLE IF NOT EXISTS `instractor` (
  `instractor_id` int(11) NOT NULL AUTO_INCREMENT,
  `instractor_name` varchar(50) NOT NULL,
  `academic_rank` varchar(100) NOT NULL,
  `distination` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  PRIMARY KEY (`instractor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=310 ;

--
-- Dumping data for table `instractor`
--

INSERT INTO `instractor` (`instractor_id`, `instractor_name`, `academic_rank`, `distination`, `department`) VALUES
(151, 'Mr.adunga habtamu                  ', 'BSc', '1st-3rd', 'information science'),
(152, 'Mr. eliyas mohamed               ', 'BSc', '1st-3rd year', 'information science'),
(153, 'Mr. obsa galchu                           ', 'MSc', '1st-3rd year', 'information science'),
(154, 'Mr.soresa                     ', 'BSc', '1st-3rd year', 'information science'),
(155, 'Ms.mokonen                          ', 'BSc', '1st-3rd year', 'information science'),
(156, 'Mr.lami resa                          ', 'BSc', '1st-3rd year', 'information science'),
(157, 'Mr. Ahmed Abera                   ', 'BSc', '1st year', 'Civil Engineering'),
(158, 'Mr.Lense Tesfaye                          ', 'BSc', '1st year', 'Civil Engineering'),
(159, 'Mr. Bizuayehu Bogale               ', 'MSc', '1st year', 'Electrical Engineering'),
(160, 'Mr.Kidus G/hiwot                  ', 'BSc', '1st year', 'Electrical Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `message`) VALUES
(1, ' <b>BHU University Presedant Mr. ABDULQADIR HUSEN Transfer his Autority to the former Presedant Mr. BALAKO</b>\r\n<br>\r\n<br>\r\n(source: Public Relation office)'),
(2, '<b> BHU university NOT start online Grade Reporting System </b>\r\n<br>\r\n<br>\r\n\r\n '),
(3, '<b>BHU University  NOT starts Teaching in Masters Program </b> \r\n<br>\r\n<br>\r\n\r\n'),
(4, '<b>BHU University Extend the schedule for the 2007  acadamic Year</b>\r\n<br>\r\n<br>\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `bulding_name` varchar(11) NOT NULL,
  `room_name` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL,
  `max_capasty` int(11) NOT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `room_name` (`room_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=143 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `bulding_name`, `room_name`, `description`, `max_capasty`) VALUES
(142, 'block 112', 'infosa section 2', 'ground', 41),
(77, 'agricultura', 'block 034', '2nd  floor', 60),
(78, 'registeral ', 'block 035', '1st and 3rd floor', 34),
(79, 'infosa 3rd ', 'block 106', '2nd floor', 80),
(80, 'computer sc', 'block 107', '3rd floor', 77),
(81, 'infosa lab ', 'block 108', '2nd  floor', 54),
(82, 'computation', 'block 109', '2nd  floor', 43),
(83, 'computer sc', 'block 110', '2nd  floor', 80),
(84, 'infosa clas', 'block 112', 'ground', 80),
(85, 'other healt', 'block 113', '2nd  floor', 80),
(86, 'geology cla', 'block 114', '2nd floor', 112),
(87, 'computation', 'block 11', '2nd floor', 80);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(30) NOT NULL,
  `acadamic_year` varchar(20) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `year_section` varchar(100) NOT NULL,
  `course` varchar(50) NOT NULL,
  `instractor` varchar(50) NOT NULL,
  `room` varchar(20) NOT NULL,
  `day` varchar(100) NOT NULL,
  `day1` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `time_start` varchar(20) NOT NULL,
  `time_end` varchar(50) NOT NULL,
  PRIMARY KEY (`schedule_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=170 ;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_id`, `department`, `acadamic_year`, `semester`, `year_section`, `course`, `instractor`, `room`, `day`, `day1`, `type`, `time_start`, `time_end`) VALUES
(1, 'information science', '2017 GC (2006 EC)', '3rd', 'infosa section one', 'INSC 3143', 'Mr.hasen', 'B112', 'Monday Tuesday   ', '', '', '2:00 AM', '4:00 AM'),
(2, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3153', 'Ms.automation', 'B112', 'Monday Tuesday   ', '', '', '2:00 AM', '4:00 AM'),
(3, 'information science', '2017GC (2009 EC)', '2nd', 'infosa section two', 'INSC 3161', 'Mr. X', 'B112', '  Wednesday  ', '', '', '2:00 AM', '4:00 AM'),
(4, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3141', 'Ms. X', 'B112', 'Monday    ', '', '', '4:30 AM', '5:20 AM'),
(5, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3142', 'Mr. X', 'B112', ' Tuesday Wednesday  ', '', '', '2:00 AM', '4:00 AM'),
(6, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3161', 'Mr. X', 'B112', 'Monday Tuesday Wednesday Thursday Friday', '', '', '2:00 AM', '4:00 AM'),
(8, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3161', 'Mr. Y', 'B112', 'Monday   Thursday ', '', '', '7:00 AM', '9:30 PM'),
(9, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3153', 'Mr. Z', 'B119', '  Wednesday  Friday', '', '', '7:00 AM', '9:30 PM'),
(10, 'information science', '2017 GC (2009EC)', '2nd', 'infosa section two', 'INSC 3143', 'Mr. XX', 'B112', '  Wednesday Thursday ', '', '', '5:30 AM', '6:20 AM');

-- --------------------------------------------------------

--
-- Table structure for table `table1`
--

CREATE TABLE IF NOT EXISTS `table1` (
  `name` varchar(100) NOT NULL,
  `path` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table1`
--

INSERT INTO `table1` (`name`, `path`) VALUES
('first file', 'bush/admin/abcd'),
('first file', 'bush/admin/abcd'),
('first file', 'bush/admin/abcd'),
('first file', 'bush/admin/abcd');

-- --------------------------------------------------------

--
-- Table structure for table `time_end`
--

CREATE TABLE IF NOT EXISTS `time_end` (
  `time_end_id` int(11) NOT NULL AUTO_INCREMENT,
  `time_end` varchar(30) NOT NULL,
  PRIMARY KEY (`time_end_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `time_end`
--

INSERT INTO `time_end` (`time_end_id`, `time_end`) VALUES
(1, '4:00 AM'),
(2, '5:20 AM'),
(3, '9:30AM'),
(4, '11:00 AM');

-- --------------------------------------------------------

--
-- Table structure for table `time_start`
--

CREATE TABLE IF NOT EXISTS `time_start` (
  `time_id` int(11) NOT NULL AUTO_INCREMENT,
  `time_start` varchar(20) NOT NULL,
  PRIMARY KEY (`time_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `time_start`
--

INSERT INTO `time_start` (`time_id`, `time_start`) VALUES
(1, '2:00 AM'),
(4, '4:30 AM'),
(5, '7:30 AM'),
(13, '10:00 AM');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `faculity` varchar(20) NOT NULL,
  `department` varchar(30) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `security_q` varchar(100) NOT NULL,
  `security_a` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `user_name`, `password`, `email`, `faculity`, `department`, `user_type`, `security_q`, `security_a`) VALUES
(39, 'chimdesa ', 'gedefa', 'bush', 'bush', 'chimdesainfosa@gmail.com', 'engineering and tech', 'information science', 'Admin', 'what we loved?', 'jesus'),
(18, 'bush', 'gedo', 'adex', 'adex', 'adex@gmail.com', 'engineering and tech', 'information science', 'Admin', 'techer', ''),
(47, 'habtamu', 'negash', 'habtish', 'habtish', 'habtish@my.com', 'engineering and tech', 'information science', 'User', '1. What is your beloved ancle name?', 'mami'),
(48, 'mersani', 'below', 'mer', 'bel', 'mersani@my.com', 'engineering and tech', 'information science', 'User', '1. What is your beloved ancle name?', 'babi'),
(49, 'tesfaye ', 'tadese', 'tasfe', 'tade', 'tasfaye@yahoo.com', 'engineering and tech', 'information science', 'Scheduler', '1. What is your beloved ancle name?', 'mesi'),
(54, 'ararsa', 'girma', 'aro', '123', 'aro@gmail.com', '', 'information science', 'User', '1. What is your beloved ancle name?', 'how to go america'),
(55, 'vbvnbn', 'zxxzcxcvc', 'tt', '12', 'cxcvcv@gmail.com', '', 'information science', 'User', '2. Where you spend your childhood time?', 'ss');

-- --------------------------------------------------------

--
-- Table structure for table `year_section`
--

CREATE TABLE IF NOT EXISTS `year_section` (
  `year_section_id` int(11) NOT NULL AUTO_INCREMENT,
  `year_section` varchar(30) NOT NULL,
  `department` varchar(100) NOT NULL,
  `no_of_student` int(30) NOT NULL,
  PRIMARY KEY (`year_section_id`),
  UNIQUE KEY `year_section` (`year_section`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=135 ;

--
-- Dumping data for table `year_section`
--

INSERT INTO `year_section` (`year_section_id`, `year_section`, `department`, `no_of_student`) VALUES
(12, 'infosa section two', 'information science', 40),
(9, 'infosa section one', 'information science', 43),
(10, 'IT 1B', 'information techinology', 47),
(11, 'IT2A', 'information techinology', 35),
(13, 'CS 3A', 'Computer Science', 34),
(14, 'CS 3B', 'Computer Science', 35),
(15, 'CS 4A', 'Computer Science', 29),
(16, 'CS 4B', 'Computer Science', 30),
(19, 'IT 1A', 'Information Technology', 29),
(18, 'IT 2A', 'Information Technology', 25),
(20, 'CIV ENG 1A', 'Civil Engineering', 25),
(21, 'CIV ENG 1B', 'Civil Engineering', 28),
(24, 'CIV ENG 1C', 'Civil Engineering', 30),
(25, 'CIV ENG 1D', 'Civil Engineering', 40),
(26, 'CIV ENG 1E', 'Civil Engineering', 40),
(27, 'CIV ENG 1F', 'Civil Engineering', 40),
(28, 'CIV ENG 2A', 'Civil Engineering', 29),
(29, 'CIV ENG 2B', 'Civil Engineering', 29),
(30, 'CHEM ENG 1A', 'Chemical Engineering', 40),
(31, 'CHEM ENG 1B', 'Chemical Engineering', 40),
(32, 'CHEM ENG 1C', 'Chemical Engineering', 42),
(33, 'CHEM ENG 2A', 'Chemical Engineering', 19),
(34, 'CHEM ENG 3A', 'Chemical Engineering', 23),
(35, 'ELEC ENG 1A', 'Electrical Engineering', 57),
(36, 'MECH ENG 1A', 'Mechanical Engineering', 36),
(37, 'ACC 1A', 'Accounting', 35),
(38, 'ACC 1B', 'Accounting', 43),
(39, 'ACC 1C', 'Accounting', 34),
(40, 'ACC 2A', 'Accounting', 46),
(41, 'ACC 2B', 'Accounting', 44);
